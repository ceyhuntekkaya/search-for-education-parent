package com.genixo.education.search.service;

public class LocationServiceTest {
}
